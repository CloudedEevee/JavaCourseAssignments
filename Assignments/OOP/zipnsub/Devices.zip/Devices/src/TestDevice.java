
public class TestDevice {

	public static void main(String[] args) {
		//////////////////////////////////// Application Simulation
		Phone p = new Phone();
		
		p.makeCall();
		p.makeCall();
		p.makeCall();
		p.makeCall();
		p.makeCall();
		
		p.playGame();
		p.playGame();
		p.playGame();
		p.playGame();
		
		p.charge();

	}

}
